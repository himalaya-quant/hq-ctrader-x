# TODO:

### Order events are globally shared 
`subscribeOrdersEvents()` returns a reference to a single `Subject`. All `.subscribe()` calls on any instance share the same event stream. This means events are not scoped to a single `client` instance if you create more than one — all instances dispatch to the same subject.


Solve hot shared observable issue, by moving static observable classes in the main 
client class. To avoid multiple instances sending events on the same subscription:

See: 
https://claude.ai/share/b149a1aa-7bcf-4e10-a485-23b7a9b33809

(check for message: "Dici che è tanto un casino implementare quel refactor?")